import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from '../features/auth/AuthProvider';
import RequireAuth from '../features/auth/RequireAuth';
import LoginPage from '../features/auth/LoginPage';
import AppLayout from '../components/layout/AppLayout';
import DashboardPage from '../pages/DashboardPage';
import UsersPage from '../features/users/UsersPage';
import AcademiesPage from '../features/academies/AcademiesPage';
import SeasonsPage from '../features/seasons/SeasonsPage';
import GroupsPage from '../features/groups/GroupsPage';
import ChildrenPage from '../features/children/ChildrenPage';
import ChildProfilePage from '../features/children/ChildProfilePage';
import PublicQuestionnairePage from '../features/public-questionnaire/PublicQuestionnairePage';
import DailyEvaluationPage from '../features/social/DailyEvaluationPage';
import WeeklySummaryPage from '../features/social/WeeklySummaryPage';
import SportsChallengesPage from '../features/sports/SportsChallengesPage';
import SportsChallengeDetailPage from '../features/sports/SportsChallengeDetailPage';
import ReportsPage from '../features/reports/ReportsPage';
import GroupReportPage from '../features/reports/GroupReportPage';
import UnauthorizedPage from '../pages/UnauthorizedPage';
import NotFoundPage from '../pages/NotFoundPage';
import LoadingScreen from '../components/ui/LoadingScreen';

function LoginRoute() {
  const { isLoading, isAuthenticated } = useAuth();

  if (isLoading) {
    return <LoadingScreen />;
  }

  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  return <LoginPage />;
}

export default function AppRouter() {
  return (
    <Routes>
      <Route path="/login" element={<LoginRoute />} />
      <Route path="/unauthorized" element={<UnauthorizedPage />} />
      <Route path="/questionnaire/:token" element={<PublicQuestionnairePage />} />

      <Route element={<RequireAuth />}>
        <Route element={<AppLayout />}>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<DashboardPage />} />

          <Route
            path="/users"
            element={
              <RequireAuth allowedRoles={['super_admin', 'admin']}>
                <UsersPage />
              </RequireAuth>
            }
          />

          <Route
            path="/academies"
            element={
              <RequireAuth allowedRoles={['super_admin', 'admin', 'manager']}>
                <AcademiesPage />
              </RequireAuth>
            }
          />

          <Route
            path="/seasons"
            element={
              <RequireAuth allowedRoles={['super_admin', 'admin', 'manager']}>
                <SeasonsPage />
              </RequireAuth>
            }
          />

          <Route
            path="/groups"
            element={
              <RequireAuth allowedRoles={['super_admin', 'admin', 'manager']}>
                <GroupsPage />
              </RequireAuth>
            }
          />

          <Route
            path="/children"
            element={
              <RequireAuth allowedRoles={['super_admin', 'admin', 'manager', 'coach']}>
                <ChildrenPage />
              </RequireAuth>
            }
          />

          <Route
            path="/children/:id/profile"
            element={
              <RequireAuth allowedRoles={['super_admin', 'admin', 'manager', 'coach']}>
                <ChildProfilePage />
              </RequireAuth>
            }
          />

          <Route
            path="/social/daily"
            element={
              <RequireAuth allowedRoles={['super_admin', 'admin', 'manager', 'coach']}>
                <DailyEvaluationPage />
              </RequireAuth>
            }
          />

          <Route
            path="/social/weekly"
            element={
              <RequireAuth allowedRoles={['super_admin', 'admin', 'manager', 'coach']}>
                <WeeklySummaryPage />
              </RequireAuth>
            }
          />

          <Route
            path="/sports"
            element={
              <RequireAuth allowedRoles={['super_admin', 'admin', 'manager', 'coach']}>
                <SportsChallengesPage />
              </RequireAuth>
            }
          />

          <Route
            path="/sports/challenges/:challengeId"
            element={
              <RequireAuth allowedRoles={['super_admin', 'admin', 'manager', 'coach']}>
                <SportsChallengeDetailPage />
              </RequireAuth>
            }
          />

          <Route
            path="/reports"
            element={
              <RequireAuth allowedRoles={['super_admin', 'admin', 'manager', 'coach']}>
                <ReportsPage />
              </RequireAuth>
            }
          />

          <Route
            path="/reports/groups/:groupId"
            element={
              <RequireAuth allowedRoles={['super_admin', 'admin', 'manager', 'coach']}>
                <GroupReportPage />
              </RequireAuth>
            }
          />
        </Route>
      </Route>

      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}
