import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';

function formatGroupOption(group) {
  const parts = [group.name];

  if (group.season?.name) {
    parts.push(group.season.name);
  }

  if (group.academy?.name) {
    parts.push(group.academy.name);
  }

  return parts.join(' · ');
}

export default function ReportFilters({
  academies = [],
  seasons = [],
  coaches = [],
  groups = [],
  selectedAcademyId,
  selectedSeasonId,
  selectedCoachId,
  selectedGroupId,
  selectedPeriod,
  onAcademyChange,
  onSeasonChange,
  onCoachChange,
  onGroupChange,
  onPeriodChange,
  weekStartDate,
  onWeekStartDateChange,
  onClear,
  isLoading,
}) {
  const academyOptions = academies.map((academy) => ({
    value: String(academy.id),
    label: academy.name,
  }));

  const seasonOptions = seasons.map((season) => ({
    value: String(season.id),
    label: season.academy?.name ? `${season.name} · ${season.academy.name}` : season.name,
  }));

  const coachOptions = coaches.map((coach) => ({
    value: String(coach.id),
    label: `${coach.firstName} ${coach.lastName}`.trim() || coach.email,
  }));

  const groupOptions = groups.map((group) => ({
    value: String(group.id),
    label: formatGroupOption(group),
  }));

  const periodOptions = [
    { value: 'current_week', label: 'Текуща седмица' },
    { value: 'previous_week', label: 'Предходна седмица' },
    { value: 'next_week', label: 'Следваща седмица' },
    { value: 'last_4_weeks', label: 'Последни 4 седмици' },
    { value: 'custom', label: 'Персонална дата' },
  ];

  return (
    <div className="filters-grid filters-grid-wide report-filters-grid">
      <Select
        label="Академия"
        value={selectedAcademyId}
        onChange={(event) => onAcademyChange(event.target.value)}
        options={academyOptions}
        placeholder="Всички академии"
        disabled={isLoading}
      />

      <Select
        label="Сезон"
        value={selectedSeasonId}
        onChange={(event) => onSeasonChange(event.target.value)}
        options={seasonOptions}
        placeholder="Всички сезони"
        disabled={isLoading}
      />

      <Select
        label="Треньор"
        value={selectedCoachId}
        onChange={(event) => onCoachChange(event.target.value)}
        options={coachOptions}
        placeholder="Всички треньори"
        disabled={isLoading}
      />

      <Select
        label="Група"
        value={selectedGroupId}
        onChange={(event) => onGroupChange(event.target.value)}
        options={groupOptions}
        placeholder="Всички групи"
        disabled={isLoading}
      />

      <Select
        label="Период"
        value={selectedPeriod}
        onChange={(event) => onPeriodChange(event.target.value)}
        options={periodOptions}
        placeholder="Изберете период"
        disabled={isLoading}
      />

      <Input
        label="Начало на седмица"
        type="date"
        value={weekStartDate}
        onChange={(event) => onWeekStartDateChange(event.target.value)}
        disabled={isLoading}
      />

      <div className="report-filter-action">
        <Button variant="ghost" disabled={isLoading} onClick={onClear}>
          Изчисти филтрите
        </Button>
      </div>
    </div>
  );
}
