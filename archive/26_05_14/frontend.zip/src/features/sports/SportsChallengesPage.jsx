import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Alert from '../../components/ui/Alert';
import Button from '../../components/ui/Button';
import Card from '../../components/ui/Card';
import EmptyState from '../../components/ui/EmptyState';
import LoadingScreen from '../../components/ui/LoadingScreen';
import PageHeader from '../../components/ui/PageHeader';
import { useAuth } from '../auth/AuthProvider';
import { getApiErrorMessage } from '../../utils/errorMessage';
import SportsChallengeFormModal from './SportsChallengeFormModal';
import SportsChallengeList from './SportsChallengeList';
import SportsChallengeStatusModal from './SportsChallengeStatusModal';
import SportsGroupSelector from './SportsGroupSelector';
import { CHALLENGE_STATUS_FILTER_OPTIONS } from './sportsLabels';
import sportsService from './sportsService';

const CHALLENGES_LIMIT = 20;

function mapFriendlyError(error) {
  if (error?.response?.status === 403) {
    return 'Нямате достъп до спортните предизвикателства за тази група.';
  }

  if (error?.response?.status === 404) {
    return 'Не открихме търсения ресурс. Проверете избраната група.';
  }

  if (error?.response?.status === 409) {
    return getApiErrorMessage(error, 'Операцията не може да бъде изпълнена в текущото състояние.');
  }

  return getApiErrorMessage(error, 'Възникна грешка. Опитайте отново.');
}

export default function SportsChallengesPage() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const canManageSports = ['super_admin', 'admin', 'coach'].includes(user?.role);
  const isManager = user?.role === 'manager';

  const [groups, setGroups] = useState([]);
  const [definitions, setDefinitions] = useState([]);
  const [selectedGroupId, setSelectedGroupId] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const [challenges, setChallenges] = useState([]);
  const [pagination, setPagination] = useState({
    limit: CHALLENGES_LIMIT,
    offset: 0,
    total: 0,
  });

  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const [isLoadingChallenges, setIsLoadingChallenges] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingChallenge, setEditingChallenge] = useState(null);
  const [statusChallenge, setStatusChallenge] = useState(null);

  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const loadInitialData = useCallback(async () => {
    try {
      setIsInitialLoading(true);
      setErrorMessage('');

      const [groupsResponse, definitionsResponse] = await Promise.all([
        sportsService.listGroups({ isActive: true, limit: 100, offset: 0 }),
        sportsService.listDefinitions({ isActive: true }),
      ]);

      setGroups(groupsResponse.groups);
      setDefinitions(definitionsResponse.definitions);

      if (!selectedGroupId && groupsResponse.groups.length > 0) {
        setSelectedGroupId(String(groupsResponse.groups[0].id));
      }
    } catch (error) {
      setErrorMessage(mapFriendlyError(error));
    } finally {
      setIsInitialLoading(false);
    }
  }, [selectedGroupId]);

  const loadChallenges = useCallback(async () => {
    if (!selectedGroupId) {
      setChallenges([]);
      setPagination((prev) => ({
        ...prev,
        offset: 0,
        total: 0,
      }));
      return;
    }

    try {
      setIsLoadingChallenges(true);
      setErrorMessage('');

      const response = await sportsService.listGroupChallenges(selectedGroupId, {
        status: statusFilter || undefined,
        limit: pagination.limit,
        offset: pagination.offset,
      });

      setChallenges(response.challenges);
      setPagination((prev) => ({
        limit: response.pagination?.limit ?? prev.limit,
        offset: response.pagination?.offset ?? prev.offset,
        total: response.pagination?.total ?? 0,
      }));
    } catch (error) {
      setErrorMessage(mapFriendlyError(error));
    } finally {
      setIsLoadingChallenges(false);
    }
  }, [pagination.limit, pagination.offset, selectedGroupId, statusFilter]);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  useEffect(() => {
    loadChallenges();
  }, [loadChallenges]);

  const canGoPrev = pagination.offset > 0;
  const canGoNext = pagination.offset + pagination.limit < pagination.total;

  async function handleCreateChallenge(payload) {
    if (!canManageSports || !selectedGroupId) {
      return;
    }

    try {
      setIsSaving(true);
      setErrorMessage('');
      setSuccessMessage('');

      await sportsService.createGroupChallenge(selectedGroupId, payload);

      setIsCreateModalOpen(false);
      setSuccessMessage('Предизвикателството е създадено успешно.');
      await loadChallenges();
    } catch (error) {
      setErrorMessage(mapFriendlyError(error));
    } finally {
      setIsSaving(false);
    }
  }

  async function handleEditChallenge(payload) {
    if (!canManageSports || !editingChallenge) {
      return;
    }

    try {
      setIsSaving(true);
      setErrorMessage('');
      setSuccessMessage('');

      await sportsService.updateChallenge(editingChallenge.id, payload);

      setEditingChallenge(null);
      setSuccessMessage('Предизвикателството е обновено успешно.');
      await loadChallenges();
    } catch (error) {
      setErrorMessage(mapFriendlyError(error));
    } finally {
      setIsSaving(false);
    }
  }

  async function handleUpdateStatus(status) {
    if (!canManageSports || !statusChallenge) {
      return;
    }

    try {
      setIsSaving(true);
      setErrorMessage('');
      setSuccessMessage('');

      await sportsService.updateChallengeStatus(statusChallenge.id, status);

      setStatusChallenge(null);
      setSuccessMessage('Статусът е обновен успешно.');
      await loadChallenges();
    } catch (error) {
      setErrorMessage(mapFriendlyError(error));
    } finally {
      setIsSaving(false);
    }
  }

  if (isInitialLoading) {
    return <LoadingScreen fullPage={false} />;
  }

  if (!groups.length) {
    return (
      <div className="page-stack">
        <PageHeader
          title="Спортни предизвикателства"
          description="Планиране и проследяване на спортните резултати по групи."
        />
        <Card>
          <EmptyState
            title="Няма налични групи"
            description="Добавете или активирайте група, за да стартирате спортно предизвикателство."
          />
        </Card>
      </div>
    );
  }

  return (
    <div className="page-stack">
      <PageHeader
        title="Спортни предизвикателства"
        description="Планиране и проследяване на спортните резултати по групи."
        actions={
          canManageSports ? (
            <Button onClick={() => setIsCreateModalOpen(true)}>Ново предизвикателство</Button>
          ) : null
        }
      />

      {errorMessage ? <Alert type="error">{errorMessage}</Alert> : null}
      {successMessage ? <Alert type="success">{successMessage}</Alert> : null}
      {isManager ? (
        <Alert type="info">
          Режим преглед: само супер админ, админ и треньор могат да създават и редактират спортни
          предизвикателства.
        </Alert>
      ) : null}

      <Card>
        <div className="filters-grid filters-grid-wide">
          <SportsGroupSelector
            groups={groups}
            value={selectedGroupId}
            onChange={(value) => {
              setSelectedGroupId(value);
              setPagination((prev) => ({ ...prev, offset: 0 }));
              setSuccessMessage('');
            }}
            disabled={isLoadingChallenges || isSaving}
          />

          <label className="form-field">
            <span className="form-label">Статус</span>
            <select
              className="input select"
              value={statusFilter}
              onChange={(event) => {
                setStatusFilter(event.target.value);
                setPagination((prev) => ({ ...prev, offset: 0 }));
                setSuccessMessage('');
              }}
              disabled={isLoadingChallenges || isSaving}
            >
              {CHALLENGE_STATUS_FILTER_OPTIONS.map((option) => (
                <option key={option.value || 'all'} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </label>
        </div>
      </Card>

      <Card title="Предизвикателства">
        <SportsChallengeList
          challenges={challenges}
          isLoading={isLoadingChallenges}
          canManage={canManageSports}
          onOpen={(challenge) => navigate(`/sports/challenges/${challenge.id}`)}
          onEdit={(challenge) => setEditingChallenge(challenge)}
          onStatus={(challenge) => setStatusChallenge(challenge)}
        />

        <div className="pagination-row">
          <span>
            Показани: {Math.min(pagination.offset + 1, pagination.total || 0)}-
            {Math.min(pagination.offset + pagination.limit, pagination.total)} от {pagination.total}
          </span>
          <div className="pagination-actions">
            <Button
              variant="secondary"
              size="sm"
              disabled={!canGoPrev || isLoadingChallenges || isSaving}
              onClick={() =>
                setPagination((prev) => ({
                  ...prev,
                  offset: Math.max(0, prev.offset - prev.limit),
                }))
              }
            >
              Назад
            </Button>
            <Button
              variant="secondary"
              size="sm"
              disabled={!canGoNext || isLoadingChallenges || isSaving}
              onClick={() =>
                setPagination((prev) => ({
                  ...prev,
                  offset: prev.offset + prev.limit,
                }))
              }
            >
              Напред
            </Button>
          </div>
        </div>
      </Card>

      {canManageSports ? (
        <SportsChallengeFormModal
          mode="create"
          isOpen={isCreateModalOpen}
          definitions={definitions}
          isSaving={isSaving}
          onClose={() => setIsCreateModalOpen(false)}
          onSubmit={handleCreateChallenge}
        />
      ) : null}

      {canManageSports ? (
        <SportsChallengeFormModal
          mode="edit"
          isOpen={Boolean(editingChallenge)}
          definitions={definitions}
          initialValues={
            editingChallenge
              ? {
                  title: editingChallenge.title,
                  description: editingChallenge.description,
                  startsOn: editingChallenge.startsOn,
                  endsOn: editingChallenge.endsOn,
                  targetReductionPercent: editingChallenge.targetReductionPercent,
                  failSafeThresholdPercent: editingChallenge.failSafeThresholdPercent,
                }
              : null
          }
          isSaving={isSaving}
          onClose={() => setEditingChallenge(null)}
          onSubmit={handleEditChallenge}
        />
      ) : null}

      {canManageSports ? (
        <SportsChallengeStatusModal
          isOpen={Boolean(statusChallenge)}
          currentStatus={statusChallenge?.status}
          isSaving={isSaving}
          onClose={() => setStatusChallenge(null)}
          onSubmit={handleUpdateStatus}
        />
      ) : null}
    </div>
  );
}
