import Select from '../../components/ui/Select';

function formatGroupOption(group) {
  const parts = [group.name];

  if (group.season?.name) {
    parts.push(group.season.name);
  }

  if (group.academy?.name) {
    parts.push(group.academy.name);
  }

  return parts.join(' · ');
}

export default function SportsGroupSelector({ groups = [], value, onChange, disabled = false }) {
  const options = groups.map((group) => ({
    value: String(group.id),
    label: formatGroupOption(group),
  }));

  return (
    <Select
      label="Група"
      value={value}
      onChange={(event) => onChange(event.target.value)}
      options={options}
      placeholder="Изберете група"
      disabled={disabled}
    />
  );
}
