import { Outlet } from 'react-router-dom';
import { useState } from 'react';
import { useAuth } from '../../features/auth/AuthProvider';
import Sidebar, { getNavigationItemsByRole } from './Sidebar';
import Topbar from './Topbar';
import MobileNav from './MobileNav';

export default function AppLayout() {
  const { user, logout } = useAuth();
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);

  const navigationItems = getNavigationItemsByRole(user?.role);

  return (
    <div className="app-shell">
      <div className="desktop-sidebar">
        <Sidebar items={navigationItems} />
      </div>

      <div className="app-main">
        <Topbar
          user={user}
          onMenuClick={() => setIsMobileNavOpen(true)}
          onLogout={logout}
        />

        <main className="app-content">
          <Outlet />
        </main>
      </div>

      <MobileNav
        isOpen={isMobileNavOpen}
        items={navigationItems}
        onClose={() => setIsMobileNavOpen(false)}
      />
    </div>
  );
}
