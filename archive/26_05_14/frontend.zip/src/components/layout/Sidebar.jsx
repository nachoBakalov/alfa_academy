import { NavLink } from 'react-router-dom';

const BASE_ITEMS = [{ label: 'Dashboard', to: '/dashboard', enabled: true }];

const ROLE_ITEMS = {
  super_admin: [
    { label: 'Users', to: '/users', enabled: true },
    { label: 'Academies', to: '/academies', enabled: true },
    { label: 'Seasons', to: '/seasons', enabled: true },
    { label: 'Groups', to: '/groups', enabled: true },
    { label: 'Children', to: '/children', enabled: true },
    { label: 'Daily Evaluation', to: '/social/daily', enabled: true },
    { label: 'Weekly Summary', to: '/social/weekly', enabled: true },
    { label: 'Sports Challenges', to: '/sports', enabled: true },
    { label: 'Reports', to: '/reports', enabled: true },
  ],
  admin: [
    { label: 'Users', to: '/users', enabled: true },
    { label: 'Academies', to: '/academies', enabled: true },
    { label: 'Seasons', to: '/seasons', enabled: true },
    { label: 'Groups', to: '/groups', enabled: true },
    { label: 'Children', to: '/children', enabled: true },
    { label: 'Daily Evaluation', to: '/social/daily', enabled: true },
    { label: 'Weekly Summary', to: '/social/weekly', enabled: true },
    { label: 'Sports Challenges', to: '/sports', enabled: true },
    { label: 'Reports', to: '/reports', enabled: true },
  ],
  manager: [
    { label: 'Groups', to: '/groups', enabled: true },
    { label: 'Academies', to: '/academies', enabled: true },
    { label: 'Seasons', to: '/seasons', enabled: true },
    { label: 'Children', to: '/children', enabled: true },
    { label: 'Daily Evaluation', to: '/social/daily', enabled: true },
    { label: 'Weekly Summary', to: '/social/weekly', enabled: true },
    { label: 'Sports Challenges', to: '/sports', enabled: true },
    { label: 'Reports', to: '/reports', enabled: true },
  ],
  coach: [
    { label: 'My Groups', enabled: false },
    { label: 'Children', to: '/children', enabled: true },
    { label: 'Daily Evaluation', to: '/social/daily', enabled: true },
    { label: 'Weekly Summary', to: '/social/weekly', enabled: true },
    { label: 'Sports Challenges', to: '/sports', enabled: true },
    { label: 'Reports', to: '/reports', enabled: true },
  ],
};

export function getNavigationItemsByRole(role) {
  return [...BASE_ITEMS, ...(ROLE_ITEMS[role] || [])];
}

export default function Sidebar({ items, onNavigate }) {
  return (
    <aside className="sidebar" aria-label="Основна навигация">
      <div className="sidebar-brand">Academy App</div>

      <nav className="sidebar-nav">
        {items.map((item) => {
          if (!item.enabled) {
            return (
              <button key={item.label} className="nav-item nav-item-disabled" type="button" disabled>
                <span>{item.label}</span>
                <small>TODO</small>
              </button>
            );
          }

          return (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={onNavigate}
              className={({ isActive }) =>
                `nav-item ${isActive ? 'nav-item-active' : ''}`.trim()
              }
            >
              {item.label}
            </NavLink>
          );
        })}
      </nav>
    </aside>
  );
}
