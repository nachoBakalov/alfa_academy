import Button from '../ui/Button';

export default function Topbar({ user, onMenuClick, onLogout }) {
  const displayName = [user?.firstName, user?.lastName].filter(Boolean).join(' ').trim();

  return (
    <header className="topbar">
      <button className="mobile-menu-button" type="button" onClick={onMenuClick}>
        Меню
      </button>

      <div className="topbar-user">
        <span>{displayName || user?.email}</span>
        <Button variant="secondary" onClick={onLogout}>
          Изход
        </Button>
      </div>
    </header>
  );
}
