export default function Button({
  children,
  type = 'button',
  variant = 'primary',
  size = 'md',
  disabled = false,
  loading = false,
  onClick,
  className = '',
}) {
  const buttonClassName = `btn btn-${variant} btn-${size} ${className}`.trim();

  return (
    <button
      className={buttonClassName}
      type={type}
      disabled={disabled || loading}
      onClick={onClick}
    >
      {loading ? 'Зареждане...' : children}
    </button>
  );
}
